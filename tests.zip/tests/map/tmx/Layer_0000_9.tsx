<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.0" name="Layer_0000_9" tilewidth="16" tileheight="16" tilecount="2842" columns="58">
 <image source="../../../../../assets/side_scroll/tilesets/Free Pixel Art Forest/PNG/Background layers/Layer_0000_9.png" width="928" height="793"/>
</tileset>
