<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.0" name="Mossy - TileSet" tilewidth="16" tileheight="16" tilecount="50176" columns="224">
 <image source="../../../../../assets/side_scroll/tilesets/Mossy Tileset/Mossy - TileSet.png" width="3584" height="3584"/>
</tileset>
